bl_info = {
    "name": "Blendmate Connector (DEV)",
    "author": "Jiri Lebduska",
    "version": (0, 2, 3),
    "blender": (4, 0, 0),
    "location": "System > Blendmate",
    "description": "Connects Blender to the Blendmate desktop app via WebSockets.",
    "warning": "",
    "doc_url": "",
    "category": "System",
}

import bpy
import importlib
import sys

# List of submodules to reload
from . import connection

def register():
    # Force reload of submodules to bypass Blender/Python cache
    if "blendmate.connection" in sys.modules:
        importlib.reload(sys.modules["blendmate.connection"])
    elif ".connection" in sys.modules: # Try relative if needed
        importlib.reload(sys.modules[".connection"])
    
    # Reload the locally imported connection
    importlib.reload(connection)
    
    if connection:
        connection.register()
    else:
        print("Blendmate Error: Connection module not available, registration failed.")

def unregister():
    if connection:
        connection.unregister()

if __name__ == "__main__":
    register()
