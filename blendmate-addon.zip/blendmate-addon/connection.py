import bpy
import json
import threading
import time
import queue
try:
    from .vendor import websocket
except ImportError:
    import vendor.websocket as websocket

# Global connection state
_ws = None
_thread = None
_should_run = False
_last_node_id = None
_message_queue = queue.Queue()

def info(msg):
    print(f"[Blendmate] {msg}")

def send_to_blendmate(data):
    """Adds a message to the queue to be sent by the timer."""
    global _message_queue
    _message_queue.put(data)

def process_queue():
    """Timer callback to process the message queue and send via WebSocket."""
    global _ws, _message_queue
    
    # Podpora pro WebSocketApp i přímý WebSocket (podle bodu 4)
    is_connected = False
    try:
        if _ws:
            if hasattr(_ws, "sock") and _ws.sock: # WebSocketApp
                is_connected = _ws.sock.connected
            elif hasattr(_ws, "connected"): # WebSocket (přímý)
                is_connected = _ws.connected
    except:
        is_connected = False

    if is_connected:
        while not _message_queue.empty():
            try:
                data = _message_queue.get_nowait()
                _ws.send(json.dumps(data))
                _message_queue.task_done()
            except queue.Empty:
                break
            except Exception as e:
                info(f"Send error: {e}")
                break
    return 0.1  # Repeat every 0.1 seconds

def get_active_gn_node():
    """Returns the ID of the active node in the Geometry Nodes editor."""
    try:
        # Hledáme aktivní Node Editor přepnutý na Geometry Nodes
        # POZOR: bpy.context.screen nemusí být v handlerech vždy dostupný
        if not hasattr(bpy.context, "screen") or bpy.context.screen is None:
            return None

        for area in bpy.context.screen.areas:
            if area.type == 'NODE_EDITOR':
                space = area.spaces.active
                if space and hasattr(space, "tree_type") and space.tree_type == 'GeometryNodeTree':
                    node_tree = space.node_tree
                    if node_tree and node_tree.nodes.active:
                        active_node = node_tree.nodes.active
                        # Pro náš systém potřebujeme bl_idname (např. GeometryNodeInstanceOnPoints)
                        return active_node.bl_idname
    except Exception as e:
        print(f"[Blendmate] Context error in get_active_gn_node: {e}")
    return None

# Handlers for Issue #19 & #7
@bpy.app.handlers.persistent
def on_depsgraph_update(scene, depsgraph):
    global _last_node_id
    
    # Detekce aktivního uzlu pro Issue #7
    current_node_id = get_active_gn_node()
    if current_node_id and current_node_id != _last_node_id:
        _last_node_id = current_node_id
        send_to_blendmate({
            "type": "context", 
            "area": "gn", 
            "node_id": current_node_id
        })
    
    # Původní depsgraph_update signál
    send_to_blendmate({"type": "event", "event": "depsgraph_update"})

@bpy.app.handlers.persistent
def on_frame_change(scene):
    send_to_blendmate({"type": "event", "event": "frame_change", "frame": scene.frame_current})

@bpy.app.handlers.persistent
def on_save_post(scene):
    send_to_blendmate({"type": "event", "event": "save_post", "filename": bpy.data.filepath})

@bpy.app.handlers.persistent
def on_load_post(scene):
    send_to_blendmate({"type": "event", "event": "load_post", "filename": bpy.data.filepath})

def ws_thread():
    global _ws, _should_run
    info(f"WS Thread started. Target: ws://127.0.0.1:32123")
    while _should_run:
        try:
            # Používáme WebSocketApp pro asynchronní příjem zpráv (on_message atd.)
            # ale s robustnější smyčkou vně run_forever
            _ws = websocket.WebSocketApp("ws://127.0.0.1:32123",
                                        on_open=lambda ws: info("WS Connected"),
                                        on_message=lambda ws, msg: info(f"Recv: {msg}"),
                                        on_error=lambda ws, err: info(f"WS Error: {err}"),
                                        on_close=lambda ws, close_status, close_msg: info(f"WS Closed: {close_status} {close_msg}"))
            _ws.run_forever(ping_interval=10, ping_timeout=5)
        except Exception as e:
            info(f"Connection error: {e}")
        
        if _should_run:
            info("WS Reconnecting in 5s...")
            time.sleep(5)
    info("WS Thread exiting")

# UI Panel for development
class BLENDMATE_PT_panel(bpy.types.Panel):
    bl_label = "Blendmate Dev"
    bl_idname = "BLENDMATE_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Blendmate'

    def draw(self, context):
        layout = self.layout
        layout.label(text=f"Version: 0.2.3")
        
        global _ws
        status = "Disconnected"
        if _ws and _ws.sock and _ws.sock.connected:
            status = "Connected"
        
        layout.label(text=f"Status: {status}")
        layout.operator("blendmate.reload", text="Reload Addon", icon='FILE_REFRESH')

class BLENDMATE_OT_reload(bpy.types.Operator):
    bl_idname = "blendmate.reload"
    bl_label = "Reload Blendmate"
    bl_description = "Reloads the addon code without restarting Blender"

    def execute(self, context):
        # Force unregister and register
        try:
            unregister()
        except:
            pass
        
        # This will trigger the importlib.reload in __init__.py when register is called
        # but since we are already inside the module, we might need a more direct approach
        # if the user calls this from the UI.
        bpy.ops.preferences.addon_disable(module="blendmate-addon")
        bpy.ops.preferences.addon_enable(module="blendmate-addon")
        
        self.report({'INFO'}, "Blendmate Reloaded!")
        return {'FINISHED'}

def register():
    global _thread, _should_run
    import os
    info(f"Registering Blendmate addon v0.2.3")
    info(f"Source: {os.path.abspath(__file__)}")
    
    # Register UI classes
    bpy.utils.register_class(BLENDMATE_PT_panel)
    bpy.utils.register_class(BLENDMATE_OT_reload)

    # Register handlers
    handlers = bpy.app.handlers
    handlers.save_post.append(on_save_post)
    handlers.load_post.append(on_load_post)
    handlers.depsgraph_update_post.append(on_depsgraph_update)
    handlers.frame_change_post.append(on_frame_change)

    # Register timer for queue processing
    if not bpy.app.timers.is_registered(process_queue):
        bpy.app.timers.register(process_queue, first_interval=0.1)

    # Start WS thread
    _should_run = True
    _thread = threading.Thread(target=ws_thread, daemon=True)
    _thread.start()

def unregister():
    global _ws, _should_run
    info("Unregistering Blendmate addon")
    
    # Unregister UI classes
    try:
        bpy.utils.unregister_class(BLENDMATE_PT_panel)
        bpy.utils.unregister_class(BLENDMATE_OT_reload)
    except:
        pass

    # Unregister handlers safely
    handlers = bpy.app.handlers
    for h in [on_save_post, on_load_post, on_depsgraph_update, on_frame_change]:
        for handler_list in [handlers.save_post, handlers.load_post, handlers.depsgraph_update_post, handlers.frame_change_post]:
            if h in handler_list:
                try:
                    handler_list.remove(h)
                except ValueError:
                    pass

    # Unregister timer
    if bpy.app.timers.is_registered(process_queue):
        bpy.app.timers.unregister(process_queue)

    _should_run = False
    if _ws:
        _ws.close()
